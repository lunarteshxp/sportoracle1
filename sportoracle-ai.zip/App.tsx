import React, { useState, useEffect } from 'react';
import { Sparkles, ExternalLink, AlertCircle, Loader2, ArrowDown, ArrowLeft } from 'lucide-react';
import LeagueSelector from './components/LeagueSelector';
import DateSelector from './components/DateSelector';
import MatchCard from './components/MatchCard';
import { League, MatchPrediction, GroundingSource, POPULAR_LEAGUES } from './types';
import { fetchPredictions } from './services/geminiService';

const App: React.FC = () => {
  const [availableLeagues, setAvailableLeagues] = useState<League[]>(POPULAR_LEAGUES);
  const [selectedLeague, setSelectedLeague] = useState<League>(POPULAR_LEAGUES[0]);
  const [selectedDate, setSelectedDate] = useState<string>('upcoming');
  const [customLeagueInput, setCustomLeagueInput] = useState('');
  
  const [predictions, setPredictions] = useState<MatchPrediction[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check URL params for shared content on initialization
  const [isSharedView, setIsSharedView] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.has('share');
    }
    return false;
  });

  // Effect to load shared match data
  useEffect(() => {
    if (isSharedView) {
      const params = new URLSearchParams(window.location.search);
      const shareData = params.get('share');
      if (shareData) {
        try {
          const decoded = JSON.parse(decodeURIComponent(atob(shareData)));
          if (decoded && decoded.homeTeam) {
             setPredictions([decoded]);
             setSources([]); // Clear sources for shared view as they aren't embedded in the link
             // Try to match the league if possible to update UI state, though not strictly necessary
             const foundLeague = availableLeagues.find(l => l.name === decoded.competition || decoded.competition.includes(l.name));
             if (foundLeague) setSelectedLeague(foundLeague);
             return;
          }
        } catch (e) {
          console.error("Failed to decode shared match", e);
        }
      }
      // If decoding fails, fallback to normal view
      handleExitSharedView();
    }
  }, []);

  const handleExitSharedView = () => {
    setIsSharedView(false);
    window.history.pushState({}, '', window.location.pathname);
    // This will trigger the main data fetch effect because isSharedView changes
  };

  const loadPredictions = async (leagueName: string, date: string) => {
    setLoading(true);
    setError(null);
    setPredictions([]);
    setSources([]);
    
    try {
      const data = await fetchPredictions(leagueName, date);
      setPredictions(data.matches);
      setSources(data.sources);
    } catch (err) {
      setError("Failed to fetch predictions. Please check your connection or try a different league.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLoadMore = async () => {
    if (loadingMore) return;
    setLoadingMore(true);

    const existingMatchSignatures = predictions.map(m => `${m.homeTeam} vs ${m.awayTeam} on ${m.date}`);

    try {
      const data = await fetchPredictions(selectedLeague.name, selectedDate, existingMatchSignatures);
      if (data.matches.length > 0) {
        setPredictions(prev => [...prev, ...data.matches]);
        // Filter out duplicate sources to keep the UI clean
        setSources(prev => {
          const newSources = data.sources.filter(ns => !prev.some(ps => ps.uri === ns.uri));
          return [...prev, ...newSources];
        });
      }
    } catch (err) {
      console.error("Failed to load more predictions", err);
    } finally {
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    if (isSharedView) return; // Skip fetch if viewing shared content
    loadPredictions(selectedLeague.name, selectedDate);
  }, [selectedLeague, selectedDate, isSharedView]);

  const handleLeagueSelect = (league: League) => {
    if (isSharedView) handleExitSharedView();
    setSelectedLeague(league);
    setCustomLeagueInput('');
  };

  const handleAddLeague = (name: string) => {
    if (isSharedView) handleExitSharedView();
    const newLeague: League = {
      id: `custom-${Date.now()}`,
      name: name,
      sport: 'Other', 
      icon: '⭐'
    };
    setAvailableLeagues(prev => [...prev, newLeague]);
    handleLeagueSelect(newLeague);
  };

  const handleCustomSubmit = () => {
    if (!customLeagueInput.trim()) return;
    if (isSharedView) handleExitSharedView();
    const custom: League = {
      id: 'custom',
      name: customLeagueInput,
      sport: 'Other',
      icon: '🌍'
    };
    setSelectedLeague(custom);
  };

  const handleDateSelect = (date: string) => {
    if (isSharedView) handleExitSharedView();
    setSelectedDate(date);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#0f172a] to-[#0f172a]">
      {/* Navbar */}
      <nav className="border-b border-white/5 bg-[#0f172a]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-600 p-1.5 rounded-lg">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                SportOracle
              </span>
            </div>
            <div className="text-xs text-slate-500 font-medium px-2 py-1 bg-slate-800/50 rounded border border-white/5 hidden sm:block">
              Powered by Gemini 2.5
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {isSharedView ? (
          <div className="mb-8 animate-fade-in">
             <button 
               onClick={handleExitSharedView}
               className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 mb-6 transition-colors font-medium"
             >
               <ArrowLeft className="w-4 h-4" />
               Back to Dashboard
             </button>
             <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-4 mb-6 flex items-start sm:items-center gap-3">
               <div className="bg-indigo-500 rounded-full p-1 mt-0.5 sm:mt-0">
                 <Sparkles className="w-3 h-3 text-white" />
               </div>
               <div>
                 <h3 className="text-white font-medium">Shared Prediction View</h3>
                 <p className="text-sm text-slate-400">You are viewing a specific match shared by a user. Go back to dashboard to see more.</p>
               </div>
             </div>
          </div>
        ) : (
          <>
            {/* League Selector */}
            <section className="mb-6">
              <LeagueSelector 
                  selectedId={selectedLeague.id}
                  onSelect={handleLeagueSelect}
                  customLeague={customLeagueInput}
                  setCustomLeague={setCustomLeagueInput}
                  onCustomSubmit={handleCustomSubmit}
                  leagues={availableLeagues}
                  onAddLeague={handleAddLeague}
              />
            </section>

            {/* Date Selector */}
            <section className="mb-8">
              <DateSelector selectedDate={selectedDate} onSelectDate={handleDateSelect} />
            </section>
          </>
        )}

        {/* Status Messages */}
        <section className="mb-8">
          {loading && (
            <div className="flex flex-col items-center justify-center py-20 animate-pulse">
              <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mb-6"></div>
              <h3 className="text-xl font-medium text-white mb-2">Analyzing...</h3>
              <p className="text-slate-400">
                Scanning schedule and stats for {selectedLeague.name} 
                {selectedDate !== 'upcoming' ? ` on ${selectedDate}` : ''}...
              </p>
            </div>
          )}

          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-6 flex items-center gap-4 text-rose-200">
              <AlertCircle className="w-6 h-6 flex-shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {!loading && !error && predictions.length === 0 && (
            <div className="text-center py-16 text-slate-500 bg-slate-800/30 rounded-xl border border-dashed border-slate-700">
              <p>No matches found for {selectedLeague.name} {selectedDate !== 'upcoming' ? `on ${selectedDate}` : 'in the immediate future'}.</p>
              <p className="text-sm mt-2">Try selecting a different date or league.</p>
            </div>
          )}
        </section>

        {/* Results Grid */}
        {!loading && predictions.length > 0 && (
          <section className="animate-fade-in space-y-8">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {predictions.map((match) => (
                    <MatchCard key={match.id} match={match} />
                ))}
             </div>
             
             {/* Load More Button - Only show if not shared view */}
             {!isSharedView && (
               <div className="flex justify-center">
                  <button
                    onClick={handleLoadMore}
                    disabled={loadingMore}
                    className="group flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-300 hover:text-white rounded-full border border-slate-700 transition-all shadow-lg hover:shadow-indigo-500/10"
                  >
                    {loadingMore ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Loading more...</span>
                      </>
                    ) : (
                      <>
                        <ArrowDown className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" />
                        <span>Load More Matches</span>
                      </>
                    )}
                  </button>
               </div>
             )}
          </section>
        )}

        {/* Sources / Grounding */}
        {!loading && sources.length > 0 && (
          <section className="mt-16 pt-8 border-t border-slate-800">
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">
              Real-time Research Sources
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {sources.map((source, idx) => (
                <a 
                  key={idx} 
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 transition-colors group"
                >
                  <ExternalLink className="w-4 h-4 text-slate-500 group-hover:text-indigo-400" />
                  <span className="text-sm text-slate-300 truncate">{source.title}</span>
                </a>
              ))}
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#0f172a] mt-auto py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-600 text-sm">
            Predictions are generated by AI for entertainment purposes only. 
            Do not use this for gambling. Always verify information independently.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;