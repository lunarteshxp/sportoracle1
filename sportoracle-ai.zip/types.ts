
export interface GroundingSource {
  uri: string;
  title: string;
}

export interface MatchPrediction {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  competition: string;
  predictedWinner: 'Home' | 'Away' | 'Draw';
  predictedScore: string;
  confidence: number;
  reasoning: string;
  status?: 'Scheduled' | 'Live' | 'Finished' | 'Postponed';
  currentScore?: string;
  matchMinute?: string;
}

export interface PredictionResponse {
  matches: MatchPrediction[];
  sources: GroundingSource[];
}

export interface League {
  id: string;
  name: string;
  sport: 'Football' | 'Basketball' | 'American Football' | 'Other';
  icon: string;
}

export const POPULAR_LEAGUES: League[] = [
  { id: 'all', name: 'All Leagues', sport: 'Other', icon: '🌎' },
  { id: 'epl', name: 'English Premier League', sport: 'Football', icon: '⚽' },
  { id: 'nba', name: 'NBA', sport: 'Basketball', icon: '🏀' },
  { id: 'nfl', name: 'NFL', sport: 'American Football', icon: '🏈' },
  { id: 'laliga', name: 'La Liga', sport: 'Football', icon: '⚽' },
  { id: 'bundesliga', name: 'Bundesliga', sport: 'Football', icon: '⚽' },
  { id: 'seriea', name: 'Serie A', sport: 'Football', icon: '⚽' },
  { id: 'ucl', name: 'Champions League', sport: 'Football', icon: '🏆' },
];
