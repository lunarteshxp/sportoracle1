
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { MatchPrediction, PredictionResponse, GroundingSource } from "../types";

// Initialize Gemini client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchPredictions = async (
  leagueName: string, 
  date: string = 'upcoming', 
  excludeMatches: string[] = []
): Promise<PredictionResponse> => {
  const model = "gemini-2.5-flash";
  const now = new Date().toISOString();
  
  const isAllLeagues = leagueName === 'All Leagues';
  
  // Determine the scope of the search
  const targetContext = isAllLeagues 
    ? "major global sports leagues (including English Premier League, NBA, NFL, La Liga, Champions League, etc.)"
    : `the ${leagueName}`;

  let timePrompt = "";
  if (date === 'upcoming') {
    timePrompt = `Find the next 5 upcoming high-profile matches for ${targetContext}. If there are fewer than 5 scheduled in the next 7 days, just show those. Prioritize the most popular matches.`;
  } else {
    timePrompt = `Find high-profile matches scheduled strictly for ${date} (YYYY-MM-DD) for ${targetContext}. If there are no matches on this specific date, return an empty array.`;
  }

  let exclusionContext = "";
  if (excludeMatches.length > 0) {
    exclusionContext = `
    IMPORTANT: The user has already seen the following matches:
    ${JSON.stringify(excludeMatches)}
    
    DO NOT include these matches in your response. You MUST find DIFFERENT matches that happen after or around these times, or remaining matches for the day that haven't been listed.
    `;
  }

  const prompt = `
    Current System Time (UTC): ${now}
    
    ${timePrompt}
    ${exclusionContext}
    
    Use Google Search to find:
    1. The exact date and time of the matches.
    2. The CURRENT STATUS of the match (Scheduled, Live, Finished, or Postponed).
    3. If the match is LIVE or FINISHED, find the real-time CURRENT SCORE and match minute/status (e.g. "32'", "HT", "FT", "Q3").
    4. Recent form, key player injuries, and head-to-head stats.
    5. Based on this research, predict the winner and the final score (even if the match is live, predict the final outcome).

    Format the output as a JSON array of objects inside a markdown code block (\`\`\`json ... \`\`\`).
    The JSON structure must be:
    [
      {
        "homeTeam": "Team Name",
        "awayTeam": "Team Name",
        "date": "YYYY-MM-DD",
        "time": "HH:MM (Timezone)",
        "competition": "${isAllLeagues ? "The specific league name (e.g. NBA, Premier League)" : leagueName}",
        "status": "Scheduled" | "Live" | "Finished" | "Postponed",
        "currentScore": "X-Y" (ONLY if Live or Finished, else null),
        "matchMinute": "e.g. 45' or Q4" (Optional, if Live),
        "predictedWinner": "Home" | "Away" | "Draw",
        "predictedScore": "X-Y",
        "confidence": number (0-100),
        "reasoning": "A concise summary (max 2 sentences) of why this result is predicted (or the current state if live)."
      }
    ]
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "";
    
    // Extract JSON from markdown code block
    const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/) || text.match(/```\s*([\s\S]*?)\s*```/);
    let matches: MatchPrediction[] = [];
    
    if (jsonMatch && jsonMatch[1]) {
      try {
        const parsed = JSON.parse(jsonMatch[1]);
        // Add random IDs for rendering
        matches = Array.isArray(parsed) ? parsed.map((m: any) => ({ ...m, id: crypto.randomUUID() })) : [];
      } catch (e) {
        console.error("Failed to parse JSON from model output", e);
        // Fallback: try to find the array brackets directly
        const arrayMatch = text.match(/\[\s*{[\s\S]*}\s*\]/);
        if (arrayMatch) {
             try {
                const parsed = JSON.parse(arrayMatch[0]);
                matches = parsed.map((m: any) => ({ ...m, id: crypto.randomUUID() }));
             } catch (e2) {
                 console.error("Second attempt JSON parse failed");
             }
        }
      }
    }

    // Extract Grounding Sources
    const sources: GroundingSource[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web?.uri && chunk.web?.title) {
          sources.push({
            uri: chunk.web.uri,
            title: chunk.web.title
          });
        }
      });
    }

    return { matches, sources };
  } catch (error) {
    console.error("Error fetching predictions:", error);
    throw error;
  }
};
