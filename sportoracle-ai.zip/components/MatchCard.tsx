
import React, { useState } from 'react';
import { MatchPrediction } from '../types';
import { ChevronDown, ChevronUp, TrendingUp, Calendar, Clock, Share2, Check, Radio } from 'lucide-react';

interface MatchCardProps {
  match: MatchPrediction;
}

const MatchCard: React.FC<MatchCardProps> = ({ match }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const isLive = match.status === 'Live';
  const isFinished = match.status === 'Finished';
  const showLiveScore = (isLive || isFinished) && match.currentScore;

  const getScoreColor = (winner: string) => {
    if (winner === 'Home') return 'text-emerald-400';
    if (winner === 'Away') return 'text-rose-400';
    return 'text-yellow-400';
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 80) return 'bg-emerald-500';
    if (score >= 60) return 'bg-blue-500';
    return 'bg-yellow-500';
  };

  const generateShareUrl = () => {
    try {
      const json = JSON.stringify(match);
      const encoded = btoa(encodeURIComponent(json));
      return `${window.location.origin}${window.location.pathname}?share=${encoded}`;
    } catch (e) {
      console.error("Error generating share URL", e);
      return window.location.href;
    }
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    const shareUrl = generateShareUrl();
    const statusText = isLive ? `🔴 LIVE: ${match.currentScore}` : isFinished ? `🏁 FT: ${match.currentScore}` : '';
    const title = `${match.homeTeam} vs ${match.awayTeam} Prediction`;
    const text = `⚽ Match: ${match.homeTeam} vs ${match.awayTeam}\n${statusText ? statusText + '\n' : ''}🏆 ${match.competition}\n🔮 AI Prediction: ${match.predictedWinner} (${match.predictedScore})\nSee details: ${shareUrl}`;

    const shareData = { title, text, url: shareUrl };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(text);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  return (
    <div className={`bg-slate-800 rounded-xl overflow-hidden border shadow-lg transition-all duration-300 ${isLive ? 'border-rose-500/50 shadow-rose-900/10' : 'border-slate-700 hover:border-slate-600'}`}>
      {/* Header / Main Info */}
      <div className="p-5 cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="flex justify-between items-center text-xs text-slate-400 mb-4 font-medium uppercase tracking-wider">
          <div className="flex items-center gap-2">
             {isLive ? (
               <div className="flex items-center gap-1.5 text-rose-400 font-bold animate-pulse">
                 <Radio className="w-3 h-3" />
                 <span>LIVE {match.matchMinute && `• ${match.matchMinute}`}</span>
               </div>
             ) : (
               <>
                 <Calendar className="w-3 h-3" />
                 <span>{match.date}</span>
                 <span className="text-slate-600">|</span>
                 <Clock className="w-3 h-3" />
                 <span>{match.time}</span>
               </>
             )}
          </div>
          <div className="px-2 py-0.5 rounded bg-slate-700 text-slate-300">
            {match.competition}
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex-1 text-center sm:text-left">
            <h3 className="text-lg font-bold text-white leading-tight">{match.homeTeam}</h3>
          </div>
          
          <div className="flex flex-col items-center justify-center px-4 min-w-[80px]">
            {showLiveScore ? (
              <>
                 <div className={`text-3xl font-black tracking-tighter ${isLive ? 'text-white' : 'text-slate-300'}`}>
                    {match.currentScore}
                 </div>
                 {isLive && <div className="text-[10px] font-bold text-rose-500 mt-1">IN PLAY</div>}
                 {isFinished && <div className="text-[10px] font-bold text-slate-500 mt-1">FULL TIME</div>}
              </>
            ) : (
               <div className="text-2xl font-black text-slate-500">VS</div>
            )}
            
            <div className={`mt-2 text-xs font-bold px-2 py-0.5 rounded border border-slate-700 bg-slate-900 ${getScoreColor(match.predictedWinner)} whitespace-nowrap`}>
               AI: {match.predictedScore}
            </div>
          </div>

          <div className="flex-1 text-center sm:text-right">
            <h3 className="text-lg font-bold text-white leading-tight">{match.awayTeam}</h3>
          </div>
        </div>

        {/* Prediction Bar */}
        <div className="mt-6 flex items-center justify-between gap-4">
           <div className="flex-1">
              <div className="flex justify-between text-xs mb-1">
                 <span className="text-slate-400">Confidence</span>
                 <span className="text-white font-mono">{match.confidence}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-700 rounded-full overflow-hidden">
                 <div 
                    className={`h-full rounded-full ${getConfidenceColor(match.confidence)}`} 
                    style={{ width: `${match.confidence}%` }}
                 ></div>
              </div>
           </div>
           
           <div className="flex items-center gap-3 pl-2">
              <button
                onClick={handleShare}
                className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-slate-700 rounded-full transition-all"
                title="Share Prediction Link"
              >
                {isCopied ? <Check className="w-5 h-5 text-emerald-500" /> : <Share2 className="w-5 h-5" />}
              </button>
              <div className="text-slate-400 hover:text-white transition-colors">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </div>
           </div>
        </div>
      </div>

      {/* Expanded Details */}
      {isExpanded && (
        <div className="bg-slate-700/30 p-5 border-t border-slate-700">
          <div className="flex items-start gap-3">
            <TrendingUp className="w-5 h-5 text-indigo-400 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-indigo-300 mb-1">AI Analysis</h4>
              <p className="text-sm text-slate-300 leading-relaxed">
                {match.reasoning}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatchCard;
