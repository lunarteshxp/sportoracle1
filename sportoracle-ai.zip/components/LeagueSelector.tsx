import React, { useState, useMemo } from 'react';
import { League } from '../types';
import { Trophy, Plus, Check, X, Filter } from 'lucide-react';

interface LeagueSelectorProps {
  selectedId: string;
  onSelect: (league: League) => void;
  customLeague: string;
  setCustomLeague: (val: string) => void;
  onCustomSubmit: () => void;
  leagues: League[];
  onAddLeague: (name: string) => void;
}

const LeagueSelector: React.FC<LeagueSelectorProps> = ({ 
  selectedId, 
  onSelect,
  customLeague,
  setCustomLeague,
  onCustomSubmit,
  leagues,
  onAddLeague
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newLeagueName, setNewLeagueName] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const handleAddSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (newLeagueName.trim()) {
      onAddLeague(newLeagueName.trim());
      setNewLeagueName('');
      setIsAdding(false);
    }
  };

  const categories = useMemo(() => {
    const sports = new Set(leagues.map(l => l.sport));
    return ['All', ...Array.from(sports).sort()];
  }, [leagues]);

  const filteredLeagues = useMemo(() => {
    if (activeCategory === 'All') return leagues;
    return leagues.filter(l => l.sport === activeCategory);
  }, [leagues, activeCategory]);

  return (
    <div className="w-full">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-5 h-5 text-indigo-400" />
        <h2 className="text-lg font-semibold text-white">Select Competition</h2>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 mb-6">
        {filteredLeagues.map((league) => (
          <button
            key={league.id}
            onClick={() => onSelect(league)}
            className={`
              flex flex-col items-center justify-center p-3 rounded-lg border transition-all duration-200
              ${selectedId === league.id 
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-500/20' 
                : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-750 hover:border-slate-600 hover:text-white'}
            `}
          >
            <span className="text-2xl mb-1">{league.icon}</span>
            <span className="text-xs font-medium text-center truncate w-full">{league.name}</span>
          </button>
        ))}

        {/* Add New League Button */}
        {isAdding ? (
          <form 
            onSubmit={handleAddSubmit}
            className="flex flex-col items-center justify-center p-2 rounded-lg border border-indigo-500 bg-slate-800 animate-in fade-in duration-200"
          >
            <input 
              type="text" 
              value={newLeagueName}
              onChange={(e) => setNewLeagueName(e.target.value)}
              placeholder="League Name..."
              className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white mb-2 focus:outline-none focus:border-indigo-500 placeholder-slate-600"
              autoFocus
            />
            <div className="flex gap-2 w-full">
              <button 
                type="submit" 
                className="flex-1 flex items-center justify-center p-1 bg-indigo-600 rounded hover:bg-indigo-500 transition-colors"
              >
                <Check className="w-3 h-3 text-white" />
              </button>
              <button 
                type="button" 
                onClick={() => setIsAdding(false)} 
                className="flex-1 flex items-center justify-center p-1 bg-slate-700 rounded hover:bg-slate-600 transition-colors"
              >
                <X className="w-3 h-3 text-slate-300" />
              </button>
            </div>
          </form>
        ) : (
          <button
            onClick={() => setIsAdding(true)}
            className="flex flex-col items-center justify-center p-3 rounded-lg border border-dashed border-slate-700 text-slate-500 hover:border-indigo-500 hover:text-indigo-400 hover:bg-slate-800/50 transition-all duration-200 group"
          >
            <Plus className="w-6 h-6 mb-1 group-hover:scale-110 transition-transform" />
            <span className="text-xs font-medium">Add League</span>
          </button>
        )}
      </div>

      {/* Custom Search */}
      <div className="relative group mb-6">
         <div className="flex gap-2">
            <input 
              type="text" 
              value={customLeague}
              onChange={(e) => setCustomLeague(e.target.value)}
              placeholder="Or type a custom league (e.g., 'French Ligue 1')..."
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              onKeyDown={(e) => e.key === 'Enter' && onCustomSubmit()}
            />
            <button 
               onClick={onCustomSubmit}
               disabled={!customLeague.trim()}
               className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
               Analyze
            </button>
         </div>
      </div>

      {/* Category Bottom Filter */}
      <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide border-t border-slate-800 pt-4">
         <div className="flex items-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-wider flex-shrink-0">
            <Filter className="w-3 h-3" />
            <span>Categories</span>
         </div>
         {categories.map((cat) => (
            <button
               key={cat}
               onClick={() => setActiveCategory(cat)}
               className={`
                  px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors
                  ${activeCategory === cat 
                     ? 'bg-slate-700 text-white border border-slate-600' 
                     : 'bg-transparent text-slate-400 border border-slate-800 hover:border-slate-700 hover:text-slate-300'}
               `}
            >
               {cat}
            </button>
         ))}
      </div>
    </div>
  );
};

export default LeagueSelector;