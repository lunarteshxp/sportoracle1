import React from 'react';
import { CalendarDays, Sun, Calendar } from 'lucide-react';

interface DateSelectorProps {
  selectedDate: string;
  onSelectDate: (date: string) => void;
}

const DateSelector: React.FC<DateSelectorProps> = ({ selectedDate, onSelectDate }) => {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

  return (
    <div className="flex flex-wrap items-center gap-3 mb-8 bg-slate-800/50 p-2 rounded-xl border border-slate-700/50 w-full md:w-auto animate-in slide-in-from-top-4 duration-500">
      <div className="flex items-center gap-2 px-3 py-1 border-r border-slate-700 hidden sm:flex">
         <CalendarDays className="w-5 h-5 text-indigo-400" />
         <span className="text-sm font-medium text-slate-300">Timeframe</span>
      </div>

      <div className="flex gap-2 flex-wrap items-center">
        <button
          onClick={() => onSelectDate('upcoming')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2
            ${selectedDate === 'upcoming' 
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
              : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}
        >
          <Calendar className="w-4 h-4" />
          Upcoming
        </button>

        <button
          onClick={() => onSelectDate(today)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2
            ${selectedDate === today 
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
              : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}
        >
          <Sun className="w-4 h-4" />
          Today
        </button>

        <button
          onClick={() => onSelectDate(tomorrow)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2
             ${selectedDate === tomorrow 
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
              : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}
        >
          <Sun className="w-4 h-4 opacity-50" />
          Tomorrow
        </button>

        <div className="relative flex items-center ml-1">
            <input 
                type="date"
                value={selectedDate === 'upcoming' ? '' : selectedDate}
                onChange={(e) => onSelectDate(e.target.value)}
                className={`
                    bg-slate-800 border rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-colors
                    ${selectedDate !== 'upcoming' && selectedDate !== today && selectedDate !== tomorrow 
                        ? 'border-indigo-500 ring-1 ring-indigo-500' 
                        : 'border-slate-700 text-slate-400'}
                `}
            />
        </div>
      </div>
    </div>
  );
};

export default DateSelector;